const express = require("express");
const cors = require("cors");
const path = require("path");
const app = express();
const port = 8080;
const route=require("../back_end/src/routes/index")

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cors());
app.use(route)

app.use(express.static(path.join(__dirname, "../front_end/css")));
app.use(express.static(path.join(__dirname, "../front_end/html")));
app.use(express.static(path.join(__dirname, "../front_end")));
app.use(express.static(path.join(__dirname, "src/images")));


app.listen(port, (error) => {
    if (!error) {
      console.log(`App is listening on port ${port}`);
    } else {
      console.log("Error, server can't start", error);
    }
  });