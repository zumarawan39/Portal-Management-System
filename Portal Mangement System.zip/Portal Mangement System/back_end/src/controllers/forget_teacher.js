var nodemailer = require("nodemailer");

let forget_teacher=(email,password)=>{
    console.log(email,password);
//     var transporter = nodemailer.createTransport({
//         service: "gmail",
//         auth: {
//           user: "zumarawan39@gmail.com",
//           pass: "hlpp ctms wmzr nmhn",
//         },
//       });

//       var mailOptions = {
//         from: "zumarawan39@gmail.com",
//         to: email,
//         subject: "Your University Email and password",
//         text: password,
//       };

//       transporter.sendMail(mailOptions, function (error, info) {
//         if (error) {
//           console.log(error);
//         } else {
//           console.log("Email sent: " + info.response);
//         }
// })
}
module.exports=forget_teacher;