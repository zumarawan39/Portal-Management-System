let { savedata_student, std_snd_fnd }=require("../modals/student_login")
let show= async (req, res) => {
    let user=await std_snd_fnd();
    res.send(user)
};
module.exports=show