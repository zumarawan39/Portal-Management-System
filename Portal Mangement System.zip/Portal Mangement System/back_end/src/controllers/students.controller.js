const { savedata_student, std_snd_fnd } = require("../modals/student_login");
var nodemailer = require("nodemailer");

const jwt = require("jsonwebtoken");
const handlePost = async (req, res) => {
  let { name, email, id, token } = req.body;
  console.log(email);
  const secret_key = "your-secret-key";
  jwt.verify(token, secret_key, async (err, decoded) => {
    if (err) {
      console.log(err);
    } else {
      let email_teacher = decoded.email;
      let user = await savedata_student(name, email, id, email_teacher);
      console.log('==================',user);
      if (user) {
        console.log("userr", user);
        var transporter = nodemailer.createTransport({
          service: "gmail",
          auth: {
            user: "zumarawan39@gmail.com",
            pass: "hlpp ctms wmzr nmhn",
          },
        });

        var mailOptions = {
          from: "zumarawan39@gmail.com",
          to: email,
          subject: "Your University Email and password",
          text: id,
        };

        transporter.sendMail(mailOptions, function (error, info) {
          if (error) {
            console.log(error);
          } else {
            console.log("Email sent: " + info.response);
          }
        });
        return res.json({ user });
      } else {
        res.send("post api is not working");
      }
    }
  });
};
module.exports = handlePost;
