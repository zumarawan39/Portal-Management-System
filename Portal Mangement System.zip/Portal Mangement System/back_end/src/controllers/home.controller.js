const path = require("path");
const home = function (req, res) {
    res.sendFile(path.join(__dirname, '..','..', '..','front_end', 'index.html'));
}
module.exports = home;

