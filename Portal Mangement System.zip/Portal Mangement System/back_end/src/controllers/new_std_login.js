const {
  savedata_student,
  std_snd_fnd,
  new_db_login,
} = require("../modals/student_login");
const path = require("path");
//login work
let new_std_login = async (req, res) => {
  let { email, password } = req.body;
  let check = await new_db_login(email, password);
  if (check == false) {
    res.send({ message: "Your passsword is not correct" });
  } else {
    res.send({ message: "Your passsword is  correct" });
  }
};
module.exports = new_std_login;
