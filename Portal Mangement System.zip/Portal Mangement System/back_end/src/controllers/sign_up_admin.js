const { savedata } = require("../modals/admin_login_sign_up");
const path = require("path");

// Define route handler
const admin_data = async (req, res) => {
    let { name, email, password, confirm_password } = req.body;
    let get_std = await savedata(name, email, password, confirm_password);
    res.send("post api is working")
    res.sendFile(path.join(__dirname, "../front_end/html/login.html"));
    return get_std;
}


module.exports = admin_data;
