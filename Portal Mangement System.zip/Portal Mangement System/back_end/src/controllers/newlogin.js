const { savedata_student, std_snd_fnd } = require("../modals/student_login");
const jwt = require("jsonwebtoken");
const newlogin = async (req, res) => {
    let { token} = req.body;
    const secret_key = 'your-secret-key';
    jwt.verify(token, secret_key, async (err, decoded) => {
       if (err) {
        console.log(err);
       } else {
        let email_teacher=decoded.email;
        console.log("newlogin======>",email_teacher);
        
        let user = await std_snd_fnd(email_teacher);
        if (user) {
            return res.json({ user });
        } else {
            res.send("post api is not working");
        }
       }
    });
};
module.exports = newlogin;
