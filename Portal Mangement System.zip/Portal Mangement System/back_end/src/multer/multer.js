
  let image= (req, res) => {
    const uploadPath = req.file.filename;
    console.log("File uploaded:", uploadPath);
    res.send({ image_path: uploadPath });
  };
  module.exports=image;
