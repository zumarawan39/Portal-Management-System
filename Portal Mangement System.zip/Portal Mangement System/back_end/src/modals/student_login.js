let mongoose = require("mongoose");
let schema = mongoose.Schema({
  name: String,
  email: String,
  id: String,
  email_teacher: String,
});
let modal = mongoose.model("students_data", schema);
const savedata_student = async (name, email, id, email_teacher) => {
  try {
    await mongoose.connect(
      "mongodb+srv://seebizbpt0623evdev41:l2Be11O5zei97LtK@tasks.fkxsczr.mongodb.net/"
    );
    const user = new modal({
      name: name,
      email: email,
      email_teacher: email_teacher,
      id: id,
    });
    await user.save();
    return true;
  } catch (error) {
    return false
  }
};
const std_snd_fnd = async (email_teacher) => {
  await mongoose.connect(
    "mongodb+srv://seebizbpt0623evdev41:l2Be11O5zei97LtK@tasks.fkxsczr.mongodb.net/"
  );
  let result = await modal.find({ email_teacher });
  return result;
};

const new_db_login = async (email, password) => {
  await mongoose.connect(
    "mongodb+srv://seebizbpt0623evdev41:l2Be11O5zei97LtK@tasks.fkxsczr.mongodb.net/"
  );
  let result = await modal.findOne({ email: email, id: password }); 
  console.log(result);
  if (!result) {
    return false;
  } else {
    return result;
  }
};
module.exports = { savedata_student, std_snd_fnd,new_db_login };
