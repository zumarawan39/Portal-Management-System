let mongoose=require("mongoose");
let jwt=require("jsonwebtoken");
let schema=mongoose.Schema({
    name:String,
    email:String,
    password:String,
    confirm_password:String,
})
let modal=mongoose.model("admin_sign_in",schema);
// Define savedata function
const savedata = async (name, email,password,confirm_password) => {
    await mongoose.connect(
      "mongodb+srv://seebizbpt0623evdev41:l2Be11O5zei97LtK@tasks.fkxsczr.mongodb.net/"
    );
    const user = new modal({
      name: name,
      email: email,
      password:password,
      confirm_password:confirm_password
    });
    await user.save();
  };
 const checkRes=async(email,password)=>{
  await mongoose.connect(
      "mongodb+srv://seebizbpt0623evdev41:l2Be11O5zei97LtK@tasks.fkxsczr.mongodb.net/"
    );
    let result=await modal.findOne({email:email, password:password})
   if(result==null){
    console.log(false);
    return false;
   }else{
    return result;
   }
  }
 
 module.exports={savedata,checkRes};
