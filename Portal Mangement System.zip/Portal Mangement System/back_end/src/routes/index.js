const express = require("express");
const multer=require("multer")
const route   = express.Router();
const path=require("path");

const home=require("../controllers/home.controller");
const sign_in=require("../controllers/sign_up_admin")
const login=require("../controllers/login")
const image=require("../multer/multer")
const studentController=require("../controllers/students.controller");
const show=require("../controllers/show")
const  newlogin=require("../controllers/newlogin")
const new_std_login=require("../controllers/new_std_login")
const forget_teacher=require("../controllers/forget_teacher")

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, path.join(__dirname, "../images"));
    },
    filename: (req, file, cb) => {
      cb(null, Date.now() + "-" + file.originalname); 
    },
  });
const upload = multer({ storage: storage });

route.get("/get",show)
route.get('/', home);
route.post("/postUser",studentController)
route.post("/post",sign_in)
route.post("/check",login)
route.post("/upload",upload.single("image"),image);
route.post("/newlogin",newlogin);
route.post("/newcheckstd",new_std_login);
route.post("/changeTPass",forget_teacher)

module.exports=route;